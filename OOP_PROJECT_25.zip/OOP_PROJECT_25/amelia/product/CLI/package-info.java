/**
 * Command-line interface for managing products.
 * <p>
 * Lets users perform product operations via the terminal or console.
 */
package amelia.product.CLI;
