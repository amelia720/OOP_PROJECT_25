/**
 * Handles product-related logic and utilities.
 * <p>
 * Contains the product data model and methods for interacting with product records.
 */
package amelia.product;
