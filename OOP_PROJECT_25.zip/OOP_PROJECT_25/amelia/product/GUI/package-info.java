/**
 * GUI components for managing products.
 * <p>
 * Contains user interface panels to add, edit, and delete products using forms and tables.
 */
package amelia.product.GUI;
