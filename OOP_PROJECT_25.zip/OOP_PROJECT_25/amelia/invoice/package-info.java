/**
 * Handles invoice-related logic and data structures.
 * <p>
 * Includes invoice models and core invoice utilities shared across different interfaces.
 */
package amelia.invoice;
