/**
 * GUI components for managing invoices.
 * <p>
 * Includes panels to add, edit, and delete invoices, and tools to display invoice information.
 */
package amelia.invoice.GUI;
