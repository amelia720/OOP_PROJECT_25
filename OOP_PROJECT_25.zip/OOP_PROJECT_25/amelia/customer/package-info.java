/**
 * Handles customer-related logic and shared classes.
 * <p>
 * Includes data models, customer utilities, and base-level operations used by both CLI and GUI.
 */
package amelia.customer;
