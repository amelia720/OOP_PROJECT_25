/**
 * GUI components for managing customers.
 * <p>
 * Contains panels for adding, editing, and deleting customer records through a graphical interface.
 */
package amelia.customer.GUI;
