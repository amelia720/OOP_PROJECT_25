/**
 * Provides command-line interface (CLI) functionality for managing customers.
 * <p>
 * Allows users to interact with customer data via the console.
 */
package amelia.customer.CLI;
