/**
 * Root package for the ShopManager Pro project.
 * <p>
 * Contains core classes such as the main application frame and shared utilities.
 */
package amelia;
